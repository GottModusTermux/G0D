# Virus-Maker "Malicious"
(for Linux,Windows,MacOS,Android)

 termux-setup-storage
 
 pkg install python2
 
 git clone https://github.com/GottModusTermux/G0D.git

 cd /G0D/VirusMaker2019/

 unzip v-maker.zip

 cd v-maker

 pip2 install -r requirements.txt

 python2 malicious.py

> after download virus open your file explorer
> find folder Malicious and open it
> chose and open folder Android if you download virus Android
__________
# https://t.me/joinchat/KCZWlxJt2j87ZuuXLocKSA
Termux Telegram Gruppe GER-Unterstützung 

https://www.youtube.com/channel/UCH2Qr1wpHMNBChgyusqjpLg?view_as=subscriber