
# Metasploit "ERROR FREE" on Termux

  git clone https://github.com/GottModusTermux/G0D.git

  pkg install unzip -y

  unzip metasploit.zip

  cd metasploit

  chmod +x * 

  bash metasploit.sh
____

  cd

  cd metasploit-framework

  msfconsole

# https://t.me/joinchat/KCZWlxJt2j87ZuuXLocKSA
>Termux Telegram Gruppe GER-Unterstützung 

https://youtu.be/B_49pqaXpAs  <--Tutorial
 Hier habe ich ein Video für euch hochgeladen,
um euch zu zeigen wie die Installertion durchgeführt wird,
und anschließend "Metasploit" gestartet wird.

Letzter Test:09.dez.2018
 mit meiner Anleitung, gibt es keine Fehler


_________
# #GottModusTermux 
