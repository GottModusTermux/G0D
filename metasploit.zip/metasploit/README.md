# Metasploit-step-by-step
16.10.2018 last Self-Test (dd.mm.yyyy)
no error on install !!
 
everything in this folder has #GottModusTermux, self-tested and the installertions commands checked themselves. 
BigThanks hax4us.com for the script.

Ultimate Linux Terminal on Android 
 #GottModusTermux <---

# Metasploit on Termux !!
 auto install without error's
 

follow the next steps for MetaSploit
 # Copy&Paste:
> apt install git

> git clone https://github.com/GottModusTermux/Metasploit-step-by-step.git

> cd Metasploit-step-by-srep

> chmod +x * 

> bash metasploit.sh
____

> cd

> cd metasploit-framework

> msfconsole


____
# #GottModusTermux 
